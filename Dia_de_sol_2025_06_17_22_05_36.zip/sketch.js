//custom variable for x coordinate of clouds
 let cloudOneX = 50;


function setup() {
  createCanvas(400, 400);
}

function draw() {
  
  background(127,182,189)
  
  //fill with a pure sandybrown
  fill(244,164,96);
 circle(350,50,100);
  
  //grass
  fill("darkseagreen");
  rect(0,300,400,100);
  
//clouds
  fill(220)
  ellipse(cloudOneX,50,100,70,20);
ellipse(cloudOneX - 40, 100, 60, 20);
ellipse(cloudOneX + 20, 150, 40, 10);

  //trunk
  fill( "peru")
  rect(40, 270, 15, 50);
  
  // leaves
  fill("olivedrab")
  triangle(25,270,45, 240 - frameCount % 290,70,270);
  
  //truk
  fill(" peru");
  rect(340, 330, 15, 50);
  //leaves
fill( "olivedrab")
 triangle(325, 330, 345, 240 -frameCount % 290, 370, 330);

  
//set shooting star to random location
lineXone = random(0,400);
lineYone = random(0, height/2);
  
  
  //set the x coordinate to the frame count
//resets at left edge
cloudOneX = frameCount % width



  
  

 


}